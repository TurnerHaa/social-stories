# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

A single Jupyter notebook (`traitors_chart.ipynb`) that renders a weekly 1080×1080 PNG chart for *The Traitors* (celebrity series): one row per player, one column per episode, showing whether each player voted for a traitor at the round table, who is a traitor, and who has been eliminated. All data lives in `tracker.csv`; output goes to `images/traitors_ep{N}.png` (previous weeks' outputs are committed there alongside `images/traitorsIcon.png`).

## Running

```bash
pip install -r requirements.txt
```

`requirements.txt` only contains `ipykernel` (no `jupyter`/`nbconvert`), so the notebook is meant to be run from an editor such as VS Code. To run headlessly, install `nbconvert` and use `jupyter nbconvert --to notebook --execute --inplace traitors_chart.ipynb`, or concatenate the code cells into a script and run it with `python`.

The **Poppins** font (weights 300, 400, 600) must be installed system-wide; matplotlib silently falls back to another font otherwise, which breaks the measured layout. There are no tests or linters.

`.github/workflows/render-chart.yml` runs the notebook on GitHub Actions whenever `tracker.csv` or the notebook changes on `main` (or when started by hand). It installs Poppins, renders the chart, uploads the PNG with the run and commits it to `images/`. A "Show tracker warnings" step reads the notebook's tracker warnings from the executed copy (stderr outputs after the `Check tracker.csv:` marker, so keep that wording) and posts them as one run annotation plus a job summary.

## Weekly workflow

1. Update `tracker.csv` (format is documented in the "setup data" cell): `Traitor_From_Episode` (blank = faithful, 1 = original traitor), `Eliminated_Episode` (blank = still in), and one `EpN` column per episode holding `Y`/`N` for whether they voted for a traitor.
2. Run all cells. Settings are inferred from the CSV rather than configured: `n_episodes` is the highest `EpN` column, `current_episode` is the latest episode with any vote, recruitment or elimination entered, and an `EpN` column that is entirely blank means that episode had no round table vote (so it's exempt from the missing-vote check). The only manual settings, in the notebook's "settings" cell, are `current_episode` (set a number to re-render an earlier week) and `annotations` (text, player name, episode, box x px, box y px).
3. The notebook emits a `warnings.warn` listing tracker problems (non-Y/N values, votes entered after a player's elimination episode, missing votes in an episode that had a round table) — check it.

## Design of the notebook

- **Time is relative to `current_episode`.** Recruitments and eliminations recorded for later episodes are ignored, and episodes after it render as hollow "future" dots, so old weeks can be re-rendered by pinning `current_episode`.
- **Row order** (cell 3): players still in sorted by surname, then eliminated players with most recent elimination first.
- **Everything is in canvas pixels.** One axes covers the whole figure with `xlim=(0,1080)`, `ylim=(1080,0)` (y points down). Sizes given to matplotlib in points go through `pt(px)` (dpi=300). Text widths are measured with `RendererAgg` (`text_width`) so legend and header placement can be computed exactly; `cap_offset` vertically centres cap height on a row. Keep new layout code in pixels using these helpers.
- **Grid geometry is derived**, not fixed: column pitch stretches from `col_first_x` to the right margin based on `n_episodes`, and row pitch stretches from `row_y0` to the bottom margin based on player count, so adding/removing players or episodes reflows automatically.
- Annotation line spacing is calibrated by measuring Poppins' real line height to hit 30px lines.
- Colours, sizes and spacing come from a brand design (comments like "as in the design" refer to it); match existing tokens in the "style" cell rather than introducing new values.
