# Traitors chart

A weekly chart for the celebrity series of *The Traitors*, showing who voted for a traitor at each round table, who the traitors are, and who has been eliminated.

![Latest chart](images/traitors_ep3.png)

## Updating the chart each week

Everything lives in **`tracker.csv`**, one row per player:

- `Traitor_From_Episode`: blank for faithfuls, otherwise the episode they became a traitor (`1` for the original traitors).
- `Eliminated_Episode`: blank while they're still in, otherwise the episode they were banished or murdered.
- `Ep1` to `Ep9`: `Y` if they voted for a traitor at that round table, `N` if not. Leave the whole column blank for an episode with no round table vote, like episodes 1 and 2 this series.

Fill in the new episode's column, then **push to `main`.** A GitHub Action renders the chart, commits it to `images/traitors_ep{N}.png`, and attaches it to the run so you can download it from the Actions tab. You can also start the action by hand from that tab.

The chart is for the latest episode with anything entered: a vote, an elimination or a recruitment. The number of episodes comes from the `Ep` columns.

If the tracker has problems (something other than Y or N, a vote for a player after they were eliminated, or a blank in an episode that had a round table), the notebook prints a warning listing them. The chart is still made anyway. On GitHub, the warnings appear at the top of the action's run page and in its summary.

### Callouts and earlier weeks

Two settings live in the notebook's settings cell instead of the CSV:

- `annotations`: callout boxes, each written as `(text, player name, episode the arrow points at, box x, box y)`, with the box position in pixels on the 1080x1080 canvas.
- `current_episode`: set a number to re-render an earlier week.

## Running it locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Then open `traitors_chart.ipynb` in VS Code (or another Jupyter editor) and run all cells.

The chart uses the [Poppins](https://fonts.google.com/specimen/Poppins) font in Light, Regular and SemiBold, which must be installed on your machine. Without it, matplotlib quietly uses another font and the text won't line up.

---

Traitors logo and branding are the property of IDTV, Studio Lambert and the BBC.
